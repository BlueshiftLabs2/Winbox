# Winbox - Browser-based VM Management Platform

Winbox is a web application that allows users to create and manage virtual machines directly in their browser. The platform supports both regular and GPU-enabled VMs without requiring any software installation on the user's side.

## Features

- **User Authentication**: Secure sign-up and sign-in system
- **VM Management**: Create up to 3 VMs with customizable specifications
- **VM Specifications**:
  - 6 to 24 vCPUs (user-selectable)
  - 32GB of RAM
  - 280GB of storage
  - Option to enable NVIDIA GPU
  - Option to use pre-installed Windows 11 or custom ISO
- **VM Access Methods**:
  - KVM console accessible directly through the web interface
  - Connection credentials for external access
- **Zero Installation**: No client-side software required

## Technology Stack

- **Frontend**: React with TypeScript, Material UI
- **Backend**: Python FastAPI, WebSockets for console access
- **Virtualization**: KVM with NoVNC for browser-based console access
- **Deployment**: Cloudflare Pages with Workers

## Installation

### Prerequisites

- Node.js 16+
- Python 3.8+
- KVM/QEMU virtualization platform
- NoVNC and Websockify for console access

### Setup Backend

1. Install Python dependencies:
```bash
pip install fastapi uvicorn sqlalchemy psycopg2-binary pyjwt bcrypt python-multipart libvirt-python websockify